let h1Time = document.getElementById("time");
let h1Value = document.getElementById("value");

let lista = [
	"alma",
	"körte",
	"banán",
	"citrom"
];


let index = -1;
let timer = null;
let currentTime = 10;

function next() {
	// Indexet növeljük 1-gyel
	index += 1;

	if (index >= lista.length) {
		// Ha nincs több elem a tömbben, akkor vége
		console.log("VÉGE");
	} else {
		show(index);
	}
}

function show(index) {
	// Mutatjuk az aktuális elemet
	h1Value.innerHTML = lista[index];

	// Hátralévő idő mutatása
	currentTime = 10;
	h1Time.innerHTML = currentTime;

	// Indítjuk a visszaszámlálást
	timer = setInterval(() => {
		currentTime -= 1;

		// Ha lejárt az időzítő
		if (currentTime < 0) {
			//!!!SAVE RESULT!!!
			// Időzítést töröljük - ez fontos!
			clearInterval(timer);
			next();
		} else {
			// Aktuális idő mutatása
			h1Time.innerHTML = currentTime;
		}
	}, 1000);
}



// Itt indul
window.onload = () => { next(); }
