//base.js


//vars
var workout_list;
var temp_workout;
var blinker;
var work_timer;
var time;
var phase_duration;
var finished = false;
var can_count;
var reps;
var result;
var index;
var audio = true;
var refresh_counter;
var start_workout_audio = new Audio('sounds/start_work.mp3');
var pause_workout_audio = new Audio('sounds/pause_work.mp3');
var end_workout_audio = new Audio('sounds/end_work.mp3');
var warmup_workout_audio = new Audio('sounds/warmup_work.mp3');
var valid_audio = new Audio('sounds/valid_sound.mp3');

//event listeners

//click events
$(document).on({
    "contextmenu": function(e) {
        e.preventDefault();
    },
    "mousedown": function(e) {        
        if (e.target.dataset.countable){
            clickable = false;
        }
        else{
            clickable = true;
        }

        if(e.which === 1 && clickable && can_count){
            if(audio){
                valid_audio.play();
            }
            reps++;
            //console.log('REP INCS');
        }
        if(e.which === 3 && clickable && can_count){
            reps--;
            //console.log('REP DECS');
            if(reps < 0){
                reps=0;
            }
        }

        if (refresh_counter){
            $('#rep_counter').text(reps);
        }
        
    },
    "mouseup": function(e) { 
        //console.log("normal mouse up:", e.which); 
    }

});


$('#loadbutton').on('click', (e)=>{
    $('#startbutton').show();
    $('#restartbutton').hide();
    $('#loadbutton').hide();
    $('#stopbutton').hide();
    $('#fileinput').click()
});


$('#fileinput').on('change', function(e){
    if (!$('#fileinput').prop('files')[0]){
        return;
    }

    var file = $('#fileinput').prop('files')[0];

    Papa.parse(file, {
        complete: function(results) {
            workout_list = create_wo_json(results.data)

            index = -1;

            ready_to_start();
        }
    });

});


$('#audio_control').on('click', ()=>{
    if (audio){
        //set audio to false
        audio = false;
        $("#audio_control").attr("src","img/sound_off.png");
    } else{
        //set audio true
        audio = true;
        $("#audio_control").attr("src","img/sound_on.png");
    }
});


//self-defined functions

//download a file
//usage: download('the content of the file', 'filename.txt', 'text/plain');
function download(strData, strFileName, strMimeType) {
    var D = document,
        A = arguments,
        a = D.createElement("a"),
        d = A[0],
        n = A[1],
        t = A[2] || "text/plain";

    //build download link:
    a.href = "data:" + strMimeType + "charset=utf-8," + escape(strData);


    if (window.MSBlobBuilder) { // IE10
        var bb = new MSBlobBuilder();
        bb.append(strData);
        return navigator.msSaveBlob(bb, strFileName);
    } /* end if(window.MSBlobBuilder) */



    if ('download' in a) { //FF20, CH19
        a.setAttribute("download", n);
        a.innerHTML = "downloading...";
        D.body.appendChild(a);
        setTimeout(function() {
            var e = D.createEvent("MouseEvents");
            e.initMouseEvent("click", true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
            a.dispatchEvent(e);
            D.body.removeChild(a);
        }, 66);
        return true;
    }; /* end if('download' in a) */



    //do iframe dataURL download: (older W3)
    var f = D.createElement("iframe");
    D.body.appendChild(f);
    f.src = "data:" + (A[2] ? A[2] : "application/octet-stream") + (window.btoa ? ";base64" : "") + "," + (window.btoa ? window.btoa : escape)(strData);
    setTimeout(function() {
        D.body.removeChild(f);
    }, 333);
    return true;
}


//parse time in sec to min/secs format
function get_time_text(time_in_secs){

    /*
    let hours = parseInt(parseInt(time_in_secs)/3600);
    let remainder = parseInt(time_in_secs%3600);
    let mins = parseInt(parseInt(remainder)/60);
    let secs = parseInt(parseInt(time_in_secs)%60);

    //all should have been shifted to 2 digits!

    if(hours === 0 ){
        return mins.toString() + ':' + secs.toString();
    } else{
        return hours.toString() + ':' + mins.toString() + ':' + secs.toString();
    }
    */

    return new Date(time_in_secs * 1000).toISOString().substr(11, 8);

}


//parses csv to list of dicts format
function create_wo_json(list){

    let json = [];
    let phase;
    let keys = list.slice(0,1);
    
    list.pop();
    list.splice(0,1);
    
    //flatten keys
    let f_keys =[];
    keys.forEach(key => {
        for(i=0; i<key.length; i++){
            f_keys.push(key[i]);
        }
    });

    for(i=0;i<list.length;i++){
        phase = {};
        for(j=0;j<list[i].length;j++){
            phase[f_keys[j]] = list[i][j];
        }
        json.push(phase);
    }
    return json;
    
}


//initialize at start
function init(){
    //hide all buttons except load
    $('#startbutton').hide();
    $('#restartbutton').hide();
    $('#loadbutton').show();
    $('#stopbutton').hide();
    $('#audio_control').hide();

    //delete label texts
    $('#rep_counter').text('0');
    $('#time_counter').text('--:--:--');
    $('#description').text('');

    //hide all status icons
    $('#attention_icon').hide();
    $('#pause_icon').hide();
    $('#work_icon').hide();
    $('#stop_icon').hide();

    //reset variables
    workout_list = null;
    temp_workout = null;
    blinker = null;
    work_timer = null;
    time = null;
    phase_duration = null;
    finished = null;
    can_count = null;
    result = 'Gyakorlat sorszáma;Gyakorlat leírása;Eltelt idő;Ismétlésszám\n';
    index = -1;
}


//init at load file
function ready_to_start(){
    //show only startbutton
    $('#startbutton').show();
    $('#restartbutton').hide();
    $('#loadbutton').hide();
    $('#stopbutton').hide();
    $('#audio_control').show();
    result = 'Gyakorlat sorszáma;Gyakorlat leírása;Eltelt idő;Ismétlésszám\n';

    //show audio control
}


function start_workout(){

    $('#startbutton').hide();
    $('#restartbutton').hide();
    $('#loadbutton').hide();
    $('#stopbutton').show();
    $('#audio_control').hide();

    $('#attention_icon').hide();
    $('#pause_icon').hide();
    $('#work_icon').hide();
    $('#stop_icon').hide();

    index += 1;
    can_count = false;
    finished = false;

    //IF NOT LIST OR ENDED
    if(workout_list == null || index >= workout_list.length){
        finished = true;
        stop_workout();

    } else{
        //start actual round
        work(workout_list[index], index);
    }

}


function stop_workout(){
    //show restart and load
    $('#startbutton').hide();
    $('#restartbutton').show();
    $('#loadbutton').show();
    $('#stopbutton').hide();
    $('#audio_control').show();

    $('#attention_icon').hide();
    $('#pause_icon').hide();
    $('#work_icon').hide();
    $('#stop_icon').show();

    $('#time_counter').text( '--:--:--' );
    $('#rep_counter').text( '-');
    $('#description').text('VÉGE!');

    can_count = false;

    if(work_timer){
        clearInterval(work_timer);
    }

    //SAVE(DOWNLOAD) ALL RESULTS
    if(finished){
        end_workout_audio.play();
        download(result, 'default_filename.csv', 'text/plain');
    }

}


function work(phase, index){

    //init phase
    let phase_result;
    reps = 0;
    time = phase['max'];

    $('#time_counter').text( get_time_text(time) );
    $('#description').text(phase['add'].toString());
    

    switch (phase['type']){

        case 'time':{
            start_workout_audio.play();
            refresh_counter = true;
            $('#rep_counter').text(reps.toString());
            $('#work_icon').show();
            can_count = true;
        }
        break;

        case 'rest':{
            pause_workout_audio.play();
            refresh_counter = false;

            //delay zeroizing reps by 10 secs or phase['max']!
            
            if (time >= 10) {
                setTimeout(()=>{
                    $('#rep_counter').text('0');
                },9000);
            } else {
                setTimeout(()=>{
                    $('#rep_counter').text('0');
                },time*1000);
            }
                        
            $('#pause_icon').show();
        }
        break;

        case 'warmup': {
            warmup_workout_audio.play();
            $('#rep_counter').text(reps.toString());
            $('#attention_icon').show();
        }
        break;

    }
    
    work_timer = setInterval(() => {
        time -= 1;
        if (time < 0) {

			//!!!SAVE PHASE RESULT!!!
            phase_result = (index+1).toString() + ';' + phase['add'].toString() + ';' + phase['max'].toString() + 's;' + reps.toString() + '\n';
            result += phase_result;

            //step for next phase
			clearInterval(work_timer);
			start_workout();

		} else {

			//update actual time
			$('#time_counter').text( get_time_text(time) );

		}
    }, 1000);

}


function restart_workout(){
    //show stop
    $('#startbutton').hide();
    $('#restartbutton').hide();
    $('#loadbutton').hide();
    $('#stopbutton').show();
    $('#audio_control').hide();

    //re-init index
    index = -1;

    //reset results list
    result = 'Gyakorlat sorszáma;Gyakorlat leírása;Eltelt idő;Ismétlésszám\n';

    //call start
    start_workout();
}


init();
